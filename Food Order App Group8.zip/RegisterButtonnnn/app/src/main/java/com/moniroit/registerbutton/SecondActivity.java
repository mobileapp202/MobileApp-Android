package com.moniroit.registerbutton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import com.moniroit.registerbutton.Domain.AllFoodsDomain;
import com.moniroit.registerbutton.databinding.ActivityMainBinding;
import com.moniroit.registerbutton.databinding.ActivitySecondBinding;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {
     ActivitySecondBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivitySecondBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    int[] pic= {R.drawable.food1,R.drawable.food2,R.drawable.food3,R.drawable.food4,R.drawable.food5,R.drawable.food6,R.drawable.food7,R.drawable.food8,R.drawable.food9};

    String[] name={"Beef Stew Sour Soup","Vietnamese Sour Soup","Loc Lac","Pork Rice","Spring Roll with Shrimp","Beef Steak","Chicken Porridge","Curry Noodle","Beef Noodle Soup"};
    String[] fee={"$1.0","$2.0","$3.0","$4.0","$5.0","$5.0","$6.0","$7.0","$8.0"};
    String[]add={"add","add","add","add","add","add","add","add","add"};
    
    ArrayList<User>userArrayList= new ArrayList<>();

    for( int i=0; i<pic.length; i++){

        User user= new User(name[i],fee[i],pic[i],add[i]);
        userArrayList.add(user);
    }


    AllfoodsAdapter allfoodsAdapter= new AllfoodsAdapter(SecondActivity.this,userArrayList);
     binding.listview2.setAdapter(allfoodsAdapter);
     binding.listview2.setClickable(true);
     binding.listview2.setOnItemClickListener(new AdapterView.OnItemClickListener(){

         @Override
         public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent i= new Intent(SecondActivity.this,UserActivity.class);
            i.putExtra("name", name[position]);
            i.putExtra("fee", fee[position]);
            i.putExtra("add", add[position]);
            i.putExtra("pic", pic[position]);
            startActivity(i);
         }
     });

    }


}
