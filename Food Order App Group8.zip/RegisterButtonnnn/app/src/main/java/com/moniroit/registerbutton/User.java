package com.moniroit.registerbutton;

public class User {
    String name;
    String add;
    int pic;
    String fee;

    public User(String name, String add, int pic, String fee) {
        this.name = name;
        this.add = add;
        this.pic = pic;
        this.fee = fee;
    }
}
