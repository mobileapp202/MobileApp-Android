package com.moniroit.registerbutton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.moniroit.registerbutton.databinding.ActivityUserBinding;

public class UserActivity extends AppCompatActivity {
    ActivityUserBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Intent intent= this.getIntent();
        if(intent!=null){
            String name= intent.getStringExtra("name");
            String fee= intent.getStringExtra("fee");
            String add= intent.getStringExtra("add");
            int pic = intent.getIntExtra("pic",R.drawable.food1);

            binding.foodName.setText(name);
            binding.fee.setText(fee);
            binding.profileImage.setImageResource(pic);
            binding.button.setText(add);



        }


        TextView btn= findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(UserActivity.this, FoodDetail.class));
            }
        });

    }
}