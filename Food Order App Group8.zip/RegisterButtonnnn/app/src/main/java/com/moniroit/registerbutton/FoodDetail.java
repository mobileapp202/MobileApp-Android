package com.moniroit.registerbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.moniroit.registerbutton.databinding.ActivityFoodDetailBinding;
import com.moniroit.registerbutton.databinding.ActivityUserBinding;

public class FoodDetail extends AppCompatActivity {

    TextView value;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_food_detail);
        Intent intent= this.getIntent();

            value = (TextView) findViewById(R.id.Num);

        TextView btn= findViewById(R.id.addToCart);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(FoodDetail.this, MyCart.class));
            }
        });


    }

    public void Increment(View v) {
        count++;
        value.setText("" + count);
    }

    public void Decrement(View v) {
        if (count <= 0) count = 0;
        else count--;
        value.setText("" + count);



    }


}
